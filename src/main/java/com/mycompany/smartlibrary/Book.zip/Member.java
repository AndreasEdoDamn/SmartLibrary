package com.mycompany.smartlibrary;

public class Member {
    private String memberID;
    private String name;
    private LibraryResource[] borrowedBooks = new LibraryResource[3];
}