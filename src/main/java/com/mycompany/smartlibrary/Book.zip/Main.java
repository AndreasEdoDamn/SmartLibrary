package com.mycompany.smartlibrary;

public class Main {
    public static void main(String[] args) {
        SmartLibrary smartLibrary = new SmartLibrary();

        smartLibrary.mainMenu();
    }
}