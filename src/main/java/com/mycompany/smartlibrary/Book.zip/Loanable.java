package com.mycompany.smartlibrary;

public interface Loanable {
    void borrowItem();
    void returnItem();
}