package com.mycompany.smartlibrary;

public enum ResourceType {
    BOOK,
    JOURNAL,
    MULTIMEDIA,
}
